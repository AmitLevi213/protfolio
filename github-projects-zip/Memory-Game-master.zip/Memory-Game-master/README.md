# Memory-Game
Technologies:
HTML
CSS
JS
Concentration is a round game in which all of the cards are laid face down on a surface and two cards are flipped face up over each turn. The object of the game is to turn over pairs of matching cards.
