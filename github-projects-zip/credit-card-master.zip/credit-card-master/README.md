# credit-card
A Simple way of Payment Method thats cause the bottom-line of the input green if your details are right and if the details are not correct the bottom-line of the input will be painted red and the pay button is disabled. 
